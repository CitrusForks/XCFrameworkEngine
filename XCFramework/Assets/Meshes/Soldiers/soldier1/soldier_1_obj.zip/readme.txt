﻿Low poly soldier model for games, educational, visualization and other purposes. 
Built with Maya 7, clean topology, no N-gons, mostly quads and just few triangles.
UV mapped and fully textured, unwrapping done with overlapping.
Maya 7 (.ma, .mb), OBJ (.obj with .mtl), 3ds Max 2009 (.max) and Autodesk FBX (.fbx) format included. FBX and OBJ are directly exported from Maya.
Polygons: 430 quads/ 848 triangles
Vertices: 428
Model is mapped on single 512×512 pixels texture map. Two formats included in soldier_textures.zip file: .tiff and .jpg.





